package com.mycompany.Laveko2;

import java.security.SecureRandom;
import java.util.Locale;

/** One message and the information used to track it. */
public class Message {
    public enum Status { DRAFT, SENT, STORED, DISREGARDED }

    private static final SecureRandom RANDOM = new SecureRandom();
    private static int totalMessagesSent;

    private String messageID;
    private String sender = "";
    private String recipient = "";
    private String message = "";
    private String messageHash = "";
    private int messageNumber;
    private Status status = Status.DRAFT;

    public Message() {
    }

    /** Used for messages loaded from JSON and for reproducible unit tests. */
    public Message(String messageID, String sender, String recipient, String message,
                   int messageNumber, Status status) {
        this.messageID = messageID;
        this.sender = sender;
        this.recipient = recipient;
        this.message = message;
        this.messageNumber = messageNumber;
        this.status = status;
        createMessageHash(messageNumber);
    }

    public boolean checkMessageID() {
        return messageID != null && messageID.matches("[0-9]{10}");
    }

    public String checkRecipientCell(String recipientNumber) {
        // Reference: Oracle Java Pattern documentation (see REFERENCES.md).
        if (recipientNumber != null && recipientNumber.matches("^\\+27[0-9]{9}$")) {
            return "Cell phone number successfully captured.";
        }
        return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
    }

    public String checkMessageLength(String messageText) {
        if (messageText == null || messageText.trim().isEmpty()) {
            return "Please enter a message.";
        }
        if (messageText.length() <= 250) {
            return "Message ready to send.";
        }
        return "Message exceeds 250 characters by " + (messageText.length() - 250)
                + "; please reduce the size.";
    }

    /** Generate a ten-digit ID. The manager checks IDs before adding messages. */
    public void generateMessageID() {
        long number = 1_000_000_000L + RANDOM.nextLong(9_000_000_000L);
        messageID = Long.toString(number);
    }

    public String createMessageHash(int number) {
        if (!checkMessageID() || message == null || message.trim().isEmpty()) {
            throw new IllegalStateException("Set a message and valid ID before creating its hash.");
        }
        messageNumber = number;
        String first = "";
        String last = "";
        for (String word : message.trim().split("\\s+")) {
            String cleaned = word.replaceAll("[^\\p{L}\\p{N}]", "").toUpperCase(Locale.ROOT);
            if (!cleaned.isEmpty()) {
                if (first.isEmpty()) {
                    first = cleaned;
                }
                last = cleaned;
            }
        }
        if (first.isEmpty()) {
            // A short message containing only punctuation is still a valid message.
            first = "SYMBOLS";
            last = "SYMBOLS";
        }
        messageHash = messageID.substring(0, 2) + ":" + number + ":" + first + last;
        return messageHash;
    }

    public String sentMessage(int option) {
        switch (option) {
            case 1:
                if (status != Status.SENT) {
                    totalMessagesSent++;
                }
                status = Status.SENT;
                return "Message successfully sent.";
            case 2:
                status = Status.DISREGARDED;
                return "Press 0 to delete the message.";
            case 3:
                status = Status.STORED;
                return "Message successfully stored.";
            default:
                return "Invalid option.";
        }
    }

    public String printMessages() {
        return "Message ID: " + messageID
                + "\nMessage Hash: " + messageHash
                + "\nSender: " + sender
                + "\nRecipient: " + recipient
                + "\nMessage: " + message
                + "\nStatus: " + status;
    }

    /** Maintained for compatibility with the Part 2 method name. */
    public int returnTotalMessages() {
        return totalMessagesSent;
    }

    public String getMessageID() { return messageID; }
    public String getSender() { return sender; }
    public String getRecipient() { return recipient; }
    public String getMessage() { return message; }
    public String getMessageHash() { return messageHash; }
    public int getMessageNumber() { return messageNumber; }
    public Status getStatus() { return status; }

    public void setSender(String sender) { this.sender = sender; }
    public void setRecipient(String recipient) { this.recipient = recipient; }
    public void setMessage(String message) { this.message = message; }
}

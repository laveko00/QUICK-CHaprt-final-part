package com.mycompany.Laveko2;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;

/**
 * Saves stored messages to a JSON array and reads the array back into Message[].
 * This small reader handles the flat objects written by this application.
 */
public class StoredMessageFile {
    private final Path file;

    public StoredMessageFile(Path file) {
        this.file = file;
    }

    public Message[] readMessages() throws IOException {
        if (!Files.exists(file)) {
            return new Message[0];
        }
        String json = Files.readString(file, StandardCharsets.UTF_8);
        try {
            return new Reader(json).readArray();
        } catch (IllegalArgumentException | IllegalStateException ex) {
            throw new IOException("The stored messages JSON file is invalid: " + ex.getMessage(), ex);
        }
    }

    public void storeMessages(Message[] messages) throws IOException {
        StringBuilder json = new StringBuilder("[\n");
        for (int i = 0; i < messages.length; i++) {
            Message m = messages[i];
            if (m.getStatus() != Message.Status.STORED) {
                throw new IllegalArgumentException("Only stored messages belong in the JSON file.");
            }
            json.append("  {\n")
                .append("    \"messageID\": ").append(quoted(m.getMessageID())).append(",\n")
                .append("    \"messageHash\": ").append(quoted(m.getMessageHash())).append(",\n")
                .append("    \"sender\": ").append(quoted(m.getSender())).append(",\n")
                .append("    \"recipient\": ").append(quoted(m.getRecipient())).append(",\n")
                .append("    \"message\": ").append(quoted(m.getMessage())).append(",\n")
                .append("    \"messageNumber\": ").append(m.getMessageNumber()).append(",\n")
                .append("    \"status\": \"STORED\"\n")
                .append("  }");
            if (i < messages.length - 1) {
                json.append(',');
            }
            json.append('\n');
        }
        json.append("]\n");
        // Write to a temporary file before replacing the original file.
        // Reference: Oracle Files API, https://docs.oracle.com/en/java/javase/17/docs/api/java.base/java/nio/file/Files.html
        Path absolute = file.toAbsolutePath();
        Path directory = absolute.getParent();
        Files.createDirectories(directory);
        Path temp = Files.createTempFile(directory, "quickchat-", ".json.tmp");
        try {
            Files.writeString(temp, json.toString(), StandardCharsets.UTF_8);
            try {
                Files.move(temp, absolute, StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (java.nio.file.AtomicMoveNotSupportedException ignored) {
                Files.move(temp, absolute, StandardCopyOption.REPLACE_EXISTING);
            }
        } finally {
            Files.deleteIfExists(temp);
        }
    }

    public void storeMessage(Message message) throws IOException {
        Message[] current = readMessages();
        Message[] next = Arrays.copyOf(current, current.length + 1);
        next[current.length] = message;
        storeMessages(next);
    }

    /** Escape text according to the JSON string rules (RFC 8259, Section 7). */
    private static String quoted(String text) {
        StringBuilder escaped = new StringBuilder("\"");
        for (char c : text.toCharArray()) {
            switch (c) {
                case '"': escaped.append("\\\""); break;
                case '\\': escaped.append("\\\\"); break;
                case '\n': escaped.append("\\n"); break;
                case '\r': escaped.append("\\r"); break;
                case '\t': escaped.append("\\t"); break;
                default:
                    if (c < 0x20) {
                        escaped.append(String.format("\\u%04x", (int) c));
                    } else {
                        escaped.append(c);
                    }
            }
        }
        return escaped.append('"').toString();
    }

    /** Parser for an array of objects containing strings and an integer. */
    private static final class Reader {
        private final String text;
        private int position;

        Reader(String text) { this.text = text; }

        Message[] readArray() {
            expect('[');
            Message[] messages = new Message[0];
            if (!consume(']')) {
                do {
                    Message parsed = readMessage();
                    messages = Arrays.copyOf(messages, messages.length + 1);
                    messages[messages.length - 1] = parsed;
                } while (consume(','));
                expect(']');
            }
            skipSpace();
            if (position != text.length()) {
                throw error("Unexpected text after the array");
            }
            return messages;
        }

        Message readMessage() {
            expect('{');
            String id = null, hash = null, sender = null, recipient = null, content = null;
            String status = null;
            Integer number = null;
            if (!consume('}')) {
                do {
                    String key = readString();
                    expect(':');
                    switch (key) {
                        case "messageID": id = readString(); break;
                        case "messageHash": hash = readString(); break;
                        case "sender": sender = readString(); break;
                        case "recipient": recipient = readString(); break;
                        case "message": content = readString(); break;
                        case "status": status = readString(); break;
                        case "messageNumber": number = readInteger(); break;
                        default: throw error("Unknown field: " + key);
                    }
                } while (consume(','));
                expect('}');
            }
            if (id == null || hash == null || sender == null || recipient == null
                    || content == null || number == null || !"STORED".equals(status)) {
                throw error("A stored message has missing or incorrect fields");
            }
            Message message = new Message(id, sender, recipient, content, number, Message.Status.STORED);
            if (!message.checkMessageID() || !hash.equals(message.getMessageHash())) {
                throw error("The message ID or hash is invalid");
            }
            return message;
        }

        int readInteger() {
            skipSpace();
            int start = position;
            while (position < text.length() && Character.isDigit(text.charAt(position))) {
                position++;
            }
            if (start == position) { throw error("Expected a message number"); }
            try {
                return Integer.parseInt(text.substring(start, position));
            } catch (NumberFormatException ex) {
                throw error("Message number is too large");
            }
        }

        String readString() {
            skipSpace();
            expect('"');
            StringBuilder result = new StringBuilder();
            while (position < text.length()) {
                char c = text.charAt(position++);
                if (c == '"') { return result.toString(); }
                if (c == '\\') {
                    if (position == text.length()) { throw error("Unfinished escape"); }
                    char escaped = text.charAt(position++);
                    switch (escaped) {
                        case '"': result.append('"'); break;
                        case '\\': result.append('\\'); break;
                        case '/': result.append('/'); break;
                        case 'n': result.append('\n'); break;
                        case 'r': result.append('\r'); break;
                        case 't': result.append('\t'); break;
                        case 'b': result.append('\b'); break;
                        case 'f': result.append('\f'); break;
                        case 'u':
                            if (position + 4 > text.length()) { throw error("Invalid Unicode escape"); }
                            try {
                                result.append((char) Integer.parseInt(text.substring(position, position + 4), 16));
                            } catch (NumberFormatException ex) {
                                throw error("Invalid Unicode escape");
                            }
                            position += 4;
                            break;
                        default: throw error("Invalid escape character");
                    }
                } else if (c < 0x20) {
                    throw error("Unescaped control character");
                } else {
                    result.append(c);
                }
            }
            throw error("Unclosed string");
        }

        boolean consume(char wanted) {
            skipSpace();
            if (position < text.length() && text.charAt(position) == wanted) {
                position++;
                return true;
            }
            return false;
        }

        void expect(char wanted) {
            if (!consume(wanted)) { throw error("Expected '" + wanted + "'"); }
        }

        void skipSpace() {
            while (position < text.length() && Character.isWhitespace(text.charAt(position))) {
                position++;
            }
        }

        IllegalArgumentException error(String message) {
            return new IllegalArgumentException(message + " at character " + position);
        }
    }
}

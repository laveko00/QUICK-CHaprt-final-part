package com.mycompany.Laveko2;

/**
 * Handles account registration and login for one QuickChat session.
 * The account is created at startup; passwords are not written to a file.
 */
public class Login {
    private String firstName = "";
    private String lastName = "";
    private String username = "";
    private String password = "";
    private String cellPhoneNumber = "";
    private boolean registered;

    public void setFirstName(String firstName) {
        this.firstName = firstName == null ? "" : firstName.trim();
    }

    public void setLastName(String lastName) {
        this.lastName = lastName == null ? "" : lastName.trim();
    }

    public void setUsername(String username) {
        this.username = username == null ? "" : username.trim();
    }

    public void setPassword(String password) {
        this.password = password == null ? "" : password;
    }

    public void setCellPhoneNumber(String cellPhoneNumber) {
        this.cellPhoneNumber = cellPhoneNumber == null ? "" : cellPhoneNumber.trim();
    }

    public String getCellPhoneNumber() {
        return cellPhoneNumber;
    }

    public String getUsername() {
        return username;
    }

    public boolean checkUserName() {
        return username.length() >= 1 && username.length() <= 5 && username.contains("_");
    }

    public boolean checkPasswordComplexity() {
        // A password needs a capital letter, a number and a special character.
        return password.length() >= 8
                && password.matches(".*[A-Z].*")
                && password.matches(".*[0-9].*")
                && password.matches(".*[^A-Za-z0-9].*");
    }

    public boolean checkCellPhoneNumber() {
        // +27 followed by the 9-digit national significant number.
        // Reference: https://docs.oracle.com/en/java/javase/17/docs/api/java.base/java/util/regex/Pattern.html
        return cellPhoneNumber.matches("^\\+27[0-9]{9}$");
    }

    public String registerUser() {
        registered = false;
        if (!checkUserName()) {
            return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        }
        if (!checkPasswordComplexity()) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
        if (!checkCellPhoneNumber()) {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        }
        if (firstName.isEmpty() || lastName.isEmpty()) {
            return "Please enter both your first name and last name.";
        }
        registered = true;
        return "User has been registered successfully.";
    }

    public boolean loginUser(String enteredUsername, String enteredPassword) {
        return registered && username.equals(enteredUsername) && password.equals(enteredPassword);
    }

    public String returnLoginStatus(boolean successful) {
        if (successful) {
            return "Welcome " + firstName + ", " + lastName + " it is great to see you again.";
        }
        return "Username or password incorrect, please try again.";
    }
}

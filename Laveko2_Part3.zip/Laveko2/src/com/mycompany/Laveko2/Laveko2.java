package com.mycompany.Laveko2;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.Scanner;

/** Console entry point for registration, sending and reporting messages. */
public class Laveko2 {
    private static final String STORED_FILE = "storedMessages.json";

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Login account = new Login();
        try {
            if (!registerAndLogin(input, account)) {
                return;
            }
            MessageManager manager = new MessageManager(
                    new StoredMessageFile(Paths.get(STORED_FILE)));
            System.out.println("Welcome to QuickChat.");
            int limit = askPositiveInt(input, "How many messages would you like to enter? ");
            int entered = 0;
            boolean running = true;
            while (running) {
                System.out.println("\n===== QUICKCHAT MENU =====");
                System.out.println("1) Send Messages");
                System.out.println("2) Show recently sent messages");
                System.out.println("3) Quit");
                System.out.println("4) Stored Messages");
                int choice = askInt(input, "Choose an option: ");
                switch (choice) {
                    case 1:
                        if (entered >= limit) {
                            System.out.println("You have reached your limit of " + limit + " messages.");
                            break;
                        }
                        // The for loop limits the number of messages entered in this session.
                        for (int i = entered; i < limit; i++) {
                            if (!composeMessage(input, account, manager)) {
                                break;
                            }
                            entered++;
                            System.out.println("Messages entered: " + entered + " of " + limit);
                        }
                        System.out.println("Total messages sent: " + manager.returnTotalMessages());
                        break;
                    case 2:
                        // This menu item retains the Part 2 required placeholder text.
                        System.out.println("Coming Soon.");
                        break;
                    case 3:
                        System.out.println("Total messages sent: " + manager.returnTotalMessages());
                        System.out.println("Goodbye!");
                        running = false;
                        break;
                    case 4:
                        storedMessageMenu(input, manager);
                        break;
                    default:
                        System.out.println("Invalid option. Please select 1, 2, 3 or 4.");
                }
            }
        } catch (IOException ex) {
            System.err.println("Unable to access stored messages: " + ex.getMessage());
            System.err.println("Check the JSON file and folder permissions before trying again.");
        }
    }

    private static boolean registerAndLogin(Scanner input, Login account) {
        System.out.println("===== QUICKCHAT REGISTRATION =====");
        account.setFirstName(ask(input, "First name: "));
        account.setLastName(ask(input, "Last name: "));
        while (true) {
            account.setUsername(ask(input, "Choose a username (maximum 5 characters, with _): "));
            if (account.checkUserName()) {
                System.out.println("Username successfully captured.");
                break;
            }
            System.out.println("Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.");
        }
        while (true) {
            account.setPassword(ask(input, "Choose a password: "));
            if (account.checkPasswordComplexity()) {
                System.out.println("Password successfully captured.");
                break;
            }
            System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
        }
        while (true) {
            account.setCellPhoneNumber(ask(input, "Cell number with international code (+27...): "));
            if (account.checkCellPhoneNumber()) {
                System.out.println("Cell phone number successfully added.");
                break;
            }
            System.out.println("Cell phone number incorrectly formatted or does not contain international code.");
        }
        String result = account.registerUser();
        System.out.println(result);
        if (!result.equals("User has been registered successfully.")) {
            return false;
        }
        System.out.println("\n===== QUICKCHAT LOGIN =====");
        for (int attempt = 0; attempt < 3; attempt++) {
            String user = ask(input, "Username: ");
            String password = ask(input, "Password: ");
            boolean success = account.loginUser(user, password);
            System.out.println(account.returnLoginStatus(success));
            if (success) { return true; }
        }
        System.out.println("Too many unsuccessful login attempts.");
        return false;
    }

    private static boolean composeMessage(Scanner input, Login account, MessageManager manager)
            throws IOException {
        System.out.println("\n===== NEW MESSAGE =====");
        String recipient;
        String messageText;
        Message validator = new Message();
        while (true) {
            recipient = ask(input, "Recipient (+27... or 0 to return): ");
            if (recipient.equals("0")) { return false; }
            String response = validator.checkRecipientCell(recipient);
            System.out.println(response);
            if (response.equals("Cell phone number successfully captured.")) { break; }
        }
        while (true) {
            messageText = ask(input, "Message (maximum 250 characters): ");
            String response = validator.checkMessageLength(messageText);
            System.out.println(response);
            if (response.equals("Message ready to send.")) { break; }
        }
        Message message = manager.prepareMessage(account.getCellPhoneNumber(), recipient, messageText);
        System.out.println("Message ID generated: " + message.getMessageID());
        System.out.println("Message Hash: " + message.getMessageHash());
        int option;
        do {
            System.out.println("1) Send Message");
            System.out.println("2) Disregard Message");
            System.out.println("3) Store Message for later");
            option = askInt(input, "Choose: ");
        } while (option < 1 || option > 3);

        if (option == 2) {
            System.out.println("Press 0 to delete the message.");
            while (askInt(input, "Enter 0 to confirm: ") != 0) {
                System.out.println("Please enter 0 to confirm disregarding this message.");
            }
        }
        String response = manager.addMessage(message, option);
        System.out.println(response);
        if (option == 1) {
            System.out.println("\n===== MESSAGE DETAILS =====");
            System.out.println(message.printMessages());
        }
        return true;
    }

    private static void storedMessageMenu(Scanner input, MessageManager manager)
            throws IOException {
        boolean showingMenu = true;
        while (showingMenu) {
            System.out.println("\n===== STORED MESSAGES =====");
            System.out.println("1) Display stored message senders and recipients");
            System.out.println("2) Display the longest stored message");
            System.out.println("3) Search for a message by ID");
            System.out.println("4) Search messages by recipient");
            System.out.println("5) Delete a message using its hash");
            System.out.println("6) Display the full message report");
            System.out.println("7) Return to main menu");
            int choice = askInt(input, "Choose an option: ");
            switch (choice) {
                case 1:
                    System.out.print(manager.storedContactsReport());
                    break;
                case 2:
                    Message longest = manager.longestStoredMessage();
                    System.out.println(longest == null ? "No stored messages."
                            : "Longest stored message:\n" + longest.printMessages());
                    break;
                case 3:
                    String id = ask(input, "Enter message ID: ");
                    Message found = manager.findByMessageID(id);
                    System.out.println(found == null ? "No message found for that ID."
                            : found.printMessages());
                    break;
                case 4:
                    String recipient = ask(input, "Enter recipient number: ");
                    Message[] matches = manager.searchByRecipient(recipient);
                    if (matches.length == 0) {
                        System.out.println("No messages found for that recipient.");
                    }
                    for (Message m : matches) {
                        System.out.println(m.printMessages());
                        System.out.println("--------------------");
                    }
                    break;
                case 5:
                    String hash = ask(input, "Enter message hash: ");
                    Message target = null;
                    for (Message m : manager.getStoredMessages()) {
                        if (m.getMessageHash().equals(hash)) { target = m; break; }
                    }
                    if (target == null) {
                        for (Message m : manager.getSentMessages()) {
                            if (m.getMessageHash().equals(hash)) { target = m; break; }
                        }
                    }
                    if (manager.deleteByHash(hash)) {
                        System.out.println("Message: \"" + target.getMessage()
                                + "\" successfully deleted.");
                    } else {
                        System.out.println("No message found for that hash.");
                    }
                    break;
                case 6:
                    System.out.print(manager.fullReport());
                    break;
                case 7:
                    showingMenu = false;
                    break;
                default:
                    System.out.println("Invalid option. Please select 1 to 7.");
            }
        }
    }

    private static String ask(Scanner input, String prompt) {
        System.out.print(prompt);
        return input.nextLine().trim();
    }

    private static int askInt(Scanner input, String prompt) {
        while (true) {
            String value = ask(input, prompt);
            try {
                return Integer.parseInt(value);
            } catch (NumberFormatException ex) {
                System.out.println("Please enter a number.");
            }
        }
    }

    private static int askPositiveInt(Scanner input, String prompt) {
        while (true) {
            int number = askInt(input, prompt);
            if (number > 0) { return number; }
            System.out.println("Please enter a number greater than zero.");
        }
    }
}

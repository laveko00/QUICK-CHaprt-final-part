# Sources used for the implementation

The assessment brief is the supplied **Programming 1A PROG5121 PoE (2026)**, especially pages 5–19 and the final marking rubric on pages 25–27.

1. Oracle. (n.d.). *Class Pattern (Java Platform SE 17)*. https://docs.oracle.com/en/java/javase/17/docs/api/java.base/java/util/regex/Pattern.html — used for username, cell phone, and password validation patterns.
2. Oracle. (n.d.). *Class Arrays (Java Platform SE 17)*. https://docs.oracle.com/en/java/javase/17/docs/api/java.base/java/util/Arrays.html — used for resizing and copying the message arrays.
3. Oracle. (n.d.). *Class Files (Java Platform SE 17)*. https://docs.oracle.com/en/java/javase/17/docs/api/java.base/java/nio/file/Files.html — used for reading and writing the stored-message file.
4. Bray, T. (2017). *The JavaScript Object Notation (JSON) Data Interchange Format*, RFC 8259. https://www.rfc-editor.org/rfc/rfc8259 — used for JSON array and string encoding rules.
5. JUnit Team. (n.d.). *JUnit 5 User Guide*. https://junit.org/junit5/docs/current/user-guide/ — used for the automated unit tests.
6. GitHub. (n.d.). *Building and testing Java with Maven*. https://docs.github.com/en/actions/tutorials/build-and-test-code/java-with-maven — used for the GitHub Actions workflow.

The application works offline. Maven requires internet access the first time it downloads the JUnit test dependency.

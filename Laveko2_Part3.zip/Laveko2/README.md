# QuickChat — Programming 1A final PoE

This is a Java console application. It builds on the registration/login and message-sending features from Parts 1 and 2, and adds stored-message arrays and reporting for Part 3.

## What you need

- Java JDK 17 or later.
- Apache NetBeans (open the `Laveko2` directory as a Java with Ant project), **or** Apache Ant.
- Apache Maven if you want to run the JUnit 5 tests locally. GitHub Actions runs the tests automatically after you push the repository.

## Open and run in NetBeans

1. Extract the ZIP.
2. In NetBeans, choose **File > Open Project**, then select the `Laveko2` folder.
3. Choose **Run Project**. The main class is `com.mycompany.Laveko2.Laveko2`.
4. Register using your first and last name, a username containing `_` with at most five characters, a password with eight or more characters including upper case, a digit and a special character, and a cell number such as `+27838968976`.
5. Log in using the username and password you just registered.
6. Enter the number of messages you plan to compose. Choose option 1 to send, disregard or store messages. Option 4 opens the stored messages and report submenu.

The file `storedMessages.json` is created **in the program's current working directory** when you store a message. Stored messages are loaded again when the app is reopened. A newly launched session requires registration/login again; account credentials are deliberately not saved. Sent and disregarded messages are kept in the current session's arrays; stored messages persist in JSON.

## Build and tests

From the project folder:

```sh
ant clean jar
java -jar dist/Laveko2.jar
```

Or for JUnit 5 tests and a Maven runnable JAR:

```sh
mvn clean verify
java -jar target/Laveko2-1.0-SNAPSHOT.jar
```

The repository includes `.github/workflows/TestJava.yml`. This builds the project and runs all JUnit tests on pushes, pull requests and manual workflow runs. The JUnit tests are in `test/com/mycompany/Laveko2/` and use temporary files so the tests do not alter your saved messages.

## Using the final Part 3 menu

The first menu contains:

- **1 — Send Messages:** enter a recipient, enter message text, and choose send, disregard (confirm with 0), or store.
- **2 — Show recently sent messages:** retains the Part 2-required `Coming Soon.` message.
- **3 — Quit:** exits the application.
- **4 — Stored Messages:** opens the six new Part 3 actions and a return option.

The stored-messages submenu lets you display sender and recipient, find the longest stored message, search by generated message ID, search sent/stored messages by recipient, delete by message hash, and print a full report including stored and sent messages. Messages can be found by their unique **10-digit message IDs**. Recipient numbers are a separate value.

## Assessment test data and important notes

The five example messages in the assessment are used **in JUnit test fixtures only**; the application does not preload or hard-code messages. Enter messages interactively to populate the live arrays. The assessment's fourth sample recipient `0838884567` is in local format, even though Part 2 requires an international code. The fixture retains the assessment sample; interactive entry follows the `+27` validation rule. Also, the assessment labels `0838884567` as search-by-message-ID data, although it is a phone number. The program searches generated 10-digit message IDs first and also accepts a recipient-number fallback for that inconsistent sample. The submenu provides a separate search for all messages matching a recipient.

Every displayed message has its ID, hash, sender, recipient and message content. The hash uses the first two ID digits, the zero-based message counter, and the first and last words in uppercase without punctuation. The fifth array (`messageIDs`) and fourth array (`messageHashes`) are populated along with sent, disregarded and stored message arrays.

## Final submission checklist

Before submitting, inspect and understand the code, run it with the supplied test cases, and make sure the video demonstrates the program working in your own voice. The instructions require a GitHub submission link, **at least six genuine commits per part**, and a narrated presentation. The ZIP cannot create GitHub commits, upload your repository or record your presentation. Use your own working repository and commit the changes as you review and test them. Do not upload `storedMessages.json` if it contains real phone numbers or private messages.

See `REFERENCES.md` for the documentation used by the implementation.

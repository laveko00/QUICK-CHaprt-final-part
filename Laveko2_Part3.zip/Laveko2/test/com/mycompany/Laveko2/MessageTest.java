package com.mycompany.Laveko2;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class MessageTest {
    @Test void messageLengthPassesAt250Characters() {
        Message message = new Message();
        assertEquals("Message ready to send.", message.checkMessageLength("A".repeat(250)));
        assertEquals("Message exceeds 250 characters by 3; please reduce the size.",
                message.checkMessageLength("A".repeat(253)));
    }

    @Test void recipientValidation() {
        Message message = new Message();
        assertEquals("Cell phone number successfully captured.", message.checkRecipientCell("+27718693002"));
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.",
                message.checkRecipientCell("08575975889"));
    }

    @Test void idHasTenDigits() {
        Message message = new Message();
        message.generateMessageID();
        assertTrue(message.checkMessageID());
        assertEquals(10, message.getMessageID().length());
    }

    @Test void hashUsesTwoIdDigitsMessageIndexAndFirstLastWords() {
        Message message = new Message("0012345678", "+27838968976", "+27718693002",
                "Hi Mike, can you join us for dinner tonight?", 0, Message.Status.DRAFT);
        assertEquals("00:0:HITONIGHT", message.getMessageHash());
    }

    @Test void hashSkipsPunctuationOnlyWord() {
        Message message = new Message("1212345678", "+27838968976", "+27718693002",
                "It is dinner time !", 3, Message.Status.SENT);
        assertEquals("12:3:ITTIME", message.getMessageHash());
    }

    @Test void optionsReturnRequiredMessages() {
        Message send = new Message();
        Message discard = new Message();
        Message store = new Message();
        assertEquals("Message successfully sent.", send.sentMessage(1));
        assertEquals("Press 0 to delete the message.", discard.sentMessage(2));
        assertEquals("Message successfully stored.", store.sentMessage(3));
        assertEquals(Message.Status.SENT, send.getStatus());
        assertEquals(Message.Status.DISREGARDED, discard.getStatus());
        assertEquals(Message.Status.STORED, store.getStatus());
    }

    @Test void messageDetailsContainRequiredInformation() {
        Message message = new Message("9012345678", "Kyle", "+27718693002",
                "Hello there", 1, Message.Status.STORED);
        String report = message.printMessages();
        assertTrue(report.contains("Message ID: 9012345678"));
        assertTrue(report.contains("Message Hash: 90:1:HELLOTHERE"));
        assertTrue(report.contains("Recipient: +27718693002"));
        assertTrue(report.contains("Message: Hello there"));
    }
}

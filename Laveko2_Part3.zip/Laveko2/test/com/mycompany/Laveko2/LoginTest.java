package com.mycompany.Laveko2;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class LoginTest {
    private Login validAccount() {
        Login login = new Login();
        login.setFirstName("Kyle");
        login.setLastName("Smith");
        login.setUsername("kyl_1");
        login.setPassword("Ch&&sec@ke99!");
        login.setCellPhoneNumber("+27838968976");
        return login;
    }

    @Test void correctUsername() {
        assertTrue(validAccount().checkUserName());
    }

    @Test void incorrectUsername() {
        Login login = validAccount();
        login.setUsername("kyle!!!!!!!");
        assertFalse(login.checkUserName());
        assertEquals("Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.", login.registerUser());
    }

    @Test void correctPassword() {
        assertTrue(validAccount().checkPasswordComplexity());
    }

    @Test void incorrectPassword() {
        Login login = validAccount();
        login.setPassword("password");
        assertFalse(login.checkPasswordComplexity());
        assertEquals("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.", login.registerUser());
    }

    @Test void correctPhone() {
        assertTrue(validAccount().checkCellPhoneNumber());
    }

    @Test void incorrectPhone() {
        Login login = validAccount();
        login.setCellPhoneNumber("08966553");
        assertFalse(login.checkCellPhoneNumber());
        assertEquals("Cell phone number incorrectly formatted or does not contain international code.", login.registerUser());
    }

    @Test void successfulLoginAfterRegistration() {
        Login login = validAccount();
        assertEquals("User has been registered successfully.", login.registerUser());
        assertTrue(login.loginUser("kyl_1", "Ch&&sec@ke99!"));
        assertEquals("Welcome Kyle, Smith it is great to see you again.", login.returnLoginStatus(true));
    }

    @Test void registrationRequiredAndWrongLoginFails() {
        Login login = validAccount();
        assertFalse(login.loginUser("kyl_1", "Ch&&sec@ke99!"));
        login.registerUser();
        assertFalse(login.loginUser("kyl_1", "wrong"));
        assertEquals("Username or password incorrect, please try again.", login.returnLoginStatus(false));
    }
}

package com.mycompany.Laveko2;

import java.io.IOException;
import java.util.Arrays;

/**
 * Coordinates the five arrays required for the final PoE.
 * Stored messages are loaded from JSON; the other arrays track the current run.
 */
public class MessageManager {
    private Message[] sentMessages = new Message[0];
    private Message[] disregardedMessages = new Message[0];
    private Message[] storedMessages = new Message[0];
    private String[] messageHashes = new String[0];
    private String[] messageIDs = new String[0];
    private int nextMessageNumber;
    private final StoredMessageFile file;

    public MessageManager(StoredMessageFile file) throws IOException {
        this.file = file;
        storedMessages = file.readMessages();
        for (Message message : storedMessages) {
            if (containsID(message.getMessageID())) {
                throw new IOException("Duplicate message ID in the stored messages file.");
            }
            index(message);
            nextMessageNumber = Math.max(nextMessageNumber, message.getMessageNumber() + 1);
        }
    }

    public int getNextMessageNumber() { return nextMessageNumber; }

    public Message prepareMessage(String sender, String recipient, String text) {
        Message message = new Message();
        message.setSender(sender);
        message.setRecipient(recipient);
        message.setMessage(text);
        do {
            message.generateMessageID();
        } while (containsID(message.getMessageID()));
        message.createMessageHash(nextMessageNumber);
        return message;
    }

    /** Adds a message only after its final send/store/disregard choice is known. */
    public String addMessage(Message message, int option) throws IOException {
        if (message == null || !message.checkMessageID() || message.getMessageHash().isEmpty()) {
            throw new IllegalArgumentException("Message is incomplete.");
        }
        if (containsID(message.getMessageID())) {
            throw new IllegalArgumentException("Message ID already exists.");
        }
        if (option < 1 || option > 3) {
            return "Invalid option.";
        }
        String response = message.sentMessage(option);
        if (option == 1) {
            sentMessages = append(sentMessages, message);
        } else if (option == 2) {
            disregardedMessages = append(disregardedMessages, message);
        } else {
            Message[] updated = append(storedMessages, message);
            // Do not change the arrays if saving the file fails.
            file.storeMessages(updated);
            storedMessages = updated;
        }
        index(message);
        nextMessageNumber = Math.max(nextMessageNumber, message.getMessageNumber() + 1);
        return response;
    }

    private void index(Message message) {
        messageIDs = Arrays.copyOf(messageIDs, messageIDs.length + 1);
        messageIDs[messageIDs.length - 1] = message.getMessageID();
        messageHashes = Arrays.copyOf(messageHashes, messageHashes.length + 1);
        messageHashes[messageHashes.length - 1] = message.getMessageHash();
    }

    private boolean containsID(String id) {
        for (String existing : messageIDs) {
            if (existing.equals(id)) { return true; }
        }
        return false;
    }

    private static Message[] append(Message[] messages, Message message) {
        Message[] updated = Arrays.copyOf(messages, messages.length + 1);
        updated[messages.length] = message;
        return updated;
    }

    public Message[] getSentMessages() { return sentMessages.clone(); }
    public Message[] getDisregardedMessages() { return disregardedMessages.clone(); }
    public Message[] getStoredMessages() { return storedMessages.clone(); }
    public String[] getMessageHashes() { return messageHashes.clone(); }
    public String[] getMessageIDs() { return messageIDs.clone(); }
    public int returnTotalMessages() { return sentMessages.length; }

    public Message longestStoredMessage() {
        Message longest = null;
        for (Message m : storedMessages) {
            if (longest == null || m.getMessage().length() > longest.getMessage().length()) {
                longest = m;
            }
        }
        return longest;
    }

    public Message findByMessageID(String search) {
        for (Message m : sentMessages) {
            if (m.getMessageID().equals(search)) { return m; }
        }
        for (Message m : storedMessages) {
            if (m.getMessageID().equals(search)) { return m; }
        }
        // The PDF's search-by-ID example supplies a phone number instead of a
        // generated ID. Support that sample while keeping exact ID search first.
        for (Message m : sentMessages) {
            if (m.getRecipient().equals(search)) { return m; }
        }
        for (Message m : storedMessages) {
            if (m.getRecipient().equals(search)) { return m; }
        }
        return null;
    }

    /** Search sent and stored messages, as required by the recipient test case. */
    public Message[] searchByRecipient(String recipient) {
        Message[] results = new Message[0];
        for (Message m : sentMessages) {
            if (m.getRecipient().equals(recipient)) { results = append(results, m); }
        }
        for (Message m : storedMessages) {
            if (m.getRecipient().equals(recipient)) { results = append(results, m); }
        }
        return results;
    }

    public boolean deleteByHash(String hash) throws IOException {
        for (int i = 0; i < storedMessages.length; i++) {
            if (storedMessages[i].getMessageHash().equals(hash)) {
                Message[] updated = remove(storedMessages, i);
                file.storeMessages(updated);
                storedMessages = updated;
                rebuildIndex();
                return true;
            }
        }
        for (int i = 0; i < sentMessages.length; i++) {
            if (sentMessages[i].getMessageHash().equals(hash)) {
                sentMessages = remove(sentMessages, i);
                rebuildIndex();
                return true;
            }
        }
        return false;
    }

    private static Message[] remove(Message[] messages, int index) {
        Message[] updated = new Message[messages.length - 1];
        System.arraycopy(messages, 0, updated, 0, index);
        System.arraycopy(messages, index + 1, updated, index, messages.length - index - 1);
        return updated;
    }

    private void rebuildIndex() {
        messageHashes = new String[0];
        messageIDs = new String[0];
        for (Message m : sentMessages) { index(m); }
        for (Message m : disregardedMessages) { index(m); }
        for (Message m : storedMessages) { index(m); }
    }

    public String storedContactsReport() {
        if (storedMessages.length == 0) { return "No stored messages."; }
        StringBuilder report = new StringBuilder("Stored message contacts:\n");
        for (Message m : storedMessages) {
            report.append("Sender: ").append(m.getSender())
                  .append(" | Recipient: ").append(m.getRecipient()).append('\n');
        }
        return report.toString();
    }

    public String fullReport() {
        StringBuilder report = new StringBuilder("===== QUICKCHAT MESSAGE REPORT =====\n");
        report.append("Sent messages: ").append(sentMessages.length)
              .append(" | Stored messages: ").append(storedMessages.length).append('\n');
        report.append("\nSTORED MESSAGES\n");
        appendDetails(report, storedMessages);
        report.append("\nSENT MESSAGES\n");
        appendDetails(report, sentMessages);
        return report.toString();
    }

    private static void appendDetails(StringBuilder report, Message[] messages) {
        if (messages.length == 0) {
            report.append("No messages.\n");
            return;
        }
        for (Message m : messages) {
            report.append(m.printMessages()).append("\n--------------------\n");
        }
    }
}

# Verification notes

The following checks were performed on the project in this package:

- `ant clean jar`: successful build using OpenJDK 21 compiling Java 17-compatible source.
- The 29 JUnit test methods compile successfully, and each test assertion passed in an offline JUnit-compatible local test runner. JUnit itself was not downloaded or invoked in that run because Maven and the JUnit JARs were unavailable in the verification environment. The included Maven/Actions configuration runs the same source test classes using JUnit 5 when the dependency is available.
- End-to-end Java console run: registration, login, creating sent/stored/disregarded messages, displaying contacts and longest stored message, searching by ID and recipient, full report, deleting by message hash, valid persisted JSON, and quitting all passed.
- JSON files were independently checked with a JSON parser. Saved-message examples are not included in the package; new ones are created when the app runs.

GitHub Actions is configured but has not been executed on the user's GitHub repository. Publishing commits and recording the required presentation are separate steps.

package com.mycompany.Laveko2;

import java.nio.file.Path;
import java.util.Arrays;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import static org.junit.jupiter.api.Assertions.*;

class MessageManagerTest {
    @TempDir Path directory;

    private MessageManager emptyManager() throws Exception {
        return new MessageManager(new StoredMessageFile(directory.resolve("storedMessages.json")));
    }

    private static Message fixture(int index, String recipient, String text, int status) {
        Message message = new Message("100000000" + (index + 1), "+27838968976", recipient,
                text, index, Message.Status.DRAFT);
        // The caller adds the message using the supplied option.
        return message;
    }

    /** Part 3 PDF, page 18: five messages are test data, not preloaded application data. */
    private MessageManager sampleManager() throws Exception {
        MessageManager manager = emptyManager();
        manager.addMessage(fixture(0, "+27834557896", "Did you get the cake?", 1), 1);
        manager.addMessage(fixture(1, "+27838884567",
                "Where are you? You are late! I have asked you to be on time.", 3), 3);
        manager.addMessage(fixture(2, "+27834484567", "Yohoooo, I am at your gate.", 2), 2);
        // The assessment's fourth test case uses a local-format recipient.
        manager.addMessage(fixture(3, "0838884567", "It is dinner time !", 1), 1);
        manager.addMessage(fixture(4, "+27838884567", "Ok, I am leaving without you.", 3), 3);
        return manager;
    }

    @Test void allFiveArraysArePopulatedCorrectly() throws Exception {
        MessageManager manager = sampleManager();
        assertArrayEquals(new String[]{"Did you get the cake?", "It is dinner time !"},
                Arrays.stream(manager.getSentMessages()).map(Message::getMessage).toArray(String[]::new));
        assertEquals(2, manager.getStoredMessages().length);
        assertEquals(1, manager.getDisregardedMessages().length);
        assertEquals(5, manager.getMessageHashes().length);
        assertEquals(5, manager.getMessageIDs().length);
        assertEquals(2, manager.returnTotalMessages());
    }

    @Test void longestStoredMessageMatchesPdfTestCase() throws Exception {
        assertEquals("Where are you? You are late! I have asked you to be on time.",
                sampleManager().longestStoredMessage().getMessage());
    }

    @Test void searchMessageFourById() throws Exception {
        MessageManager manager = sampleManager();
        String id = manager.getSentMessages()[1].getMessageID();
        assertEquals("It is dinner time !", manager.findByMessageID(id).getMessage());
        // The assignment also calls the recipient number a message ID in this test.
        assertEquals("It is dinner time !", manager.findByMessageID("0838884567").getMessage());
        assertNull(manager.findByMessageID("0000000000"));
    }

    @Test void searchRecipientFindsBothStoredMessages() throws Exception {
        Message[] matches = sampleManager().searchByRecipient("+27838884567");
        assertEquals(2, matches.length);
        assertEquals("Where are you? You are late! I have asked you to be on time.", matches[0].getMessage());
        assertEquals("Ok, I am leaving without you.", matches[1].getMessage());
    }

    @Test void deleteByHashRemovesMessageTwoFromArrayAndJson() throws Exception {
        MessageManager manager = sampleManager();
        String hash = manager.getStoredMessages()[0].getMessageHash();
        assertTrue(manager.deleteByHash(hash));
        assertEquals(1, manager.getStoredMessages().length);
        assertEquals("Ok, I am leaving without you.", manager.getStoredMessages()[0].getMessage());
        assertEquals(4, manager.getMessageHashes().length);
        assertFalse(manager.deleteByHash("NOT_A_HASH"));
        MessageManager reloaded = emptyManager();
        assertEquals(1, reloaded.getStoredMessages().length);
        assertEquals("Ok, I am leaving without you.", reloaded.getStoredMessages()[0].getMessage());
    }

    @Test void reportShowsHashesRecipientsAndMessages() throws Exception {
        String report = sampleManager().fullReport();
        assertTrue(report.contains("Message Hash:"));
        assertTrue(report.contains("Recipient: +27838884567"));
        assertTrue(report.contains("Where are you?"));
        assertTrue(report.contains("Did you get the cake?"));
        assertTrue(report.contains("Sent messages: 2"));
        assertTrue(report.contains("Stored messages: 2"));
    }

    @Test void contactsReportShowsSenderAndRecipient() throws Exception {
        String contacts = sampleManager().storedContactsReport();
        assertTrue(contacts.contains("Sender: +27838968976"));
        assertTrue(contacts.contains("Recipient: +27838884567"));
    }

    @Test void storedMessagesReloadFromJsonWithSequentialNextNumber() throws Exception {
        sampleManager();
        MessageManager newSession = emptyManager();
        assertEquals(2, newSession.getStoredMessages().length);
        assertEquals(5, newSession.getNextMessageNumber());
        Message message = newSession.prepareMessage("+27838968976", "+27834557896", "Next day");
        assertEquals(5, message.getMessageNumber());
        assertEquals(10, message.getMessageID().length());
        assertFalse(Arrays.asList(newSession.getMessageIDs()).contains(message.getMessageID()));
    }

    @Test void storedMessagesDoNotDuplicateOnReload() throws Exception {
        sampleManager();
        MessageManager manager = emptyManager();
        assertEquals(2, manager.getMessageIDs().length);
        assertEquals(2, manager.getMessageHashes().length);
    }

    @Test void duplicateIdIsRejected() throws Exception {
        MessageManager manager = emptyManager();
        manager.addMessage(fixture(0, "+27834557896", "Hello", 1), 1);
        assertThrows(IllegalArgumentException.class,
                () -> manager.addMessage(fixture(0, "+27834557896", "Hello", 1), 1));
    }
}

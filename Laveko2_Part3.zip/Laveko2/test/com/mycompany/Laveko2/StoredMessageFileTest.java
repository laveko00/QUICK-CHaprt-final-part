package com.mycompany.Laveko2;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import static org.junit.jupiter.api.Assertions.*;

class StoredMessageFileTest {
    @TempDir Path directory;

    @Test void missingFileMeansEmptyStoredArray() throws Exception {
        StoredMessageFile file = new StoredMessageFile(directory.resolve("missing.json"));
        assertEquals(0, file.readMessages().length);
    }

    @Test void saveAndReloadEscapedText() throws Exception {
        Path path = directory.resolve("messages.json");
        StoredMessageFile file = new StoredMessageFile(path);
        Message message = new Message("1234567890", "Kyle", "+27838884567",
                "Hello, \"Mike\"! Backslash \\ and a newline\nThanks", 0, Message.Status.STORED);
        file.storeMessages(new Message[]{message});
        String json = Files.readString(path, StandardCharsets.UTF_8);
        assertTrue(json.trim().startsWith("["));
        assertTrue(json.contains("\\\"Mike\\\""));
        assertTrue(json.contains("\\\\"));
        assertTrue(json.contains("\\n"));
        Message[] reread = file.readMessages();
        assertEquals(1, reread.length);
        assertEquals(message.getMessage(), reread[0].getMessage());
        assertEquals(message.getMessageHash(), reread[0].getMessageHash());
        assertEquals("Kyle", reread[0].getSender());
    }

    @Test void deleteLeavesValidEmptyJsonArray() throws Exception {
        StoredMessageFile file = new StoredMessageFile(directory.resolve("messages.json"));
        file.storeMessages(new Message[0]);
        assertArrayEquals(new Message[0], file.readMessages());
    }

    @Test void invalidJsonProducesMeaningfulError() throws Exception {
        Path path = directory.resolve("messages.json");
        Files.writeString(path, "{\"message\":\"not an array\"}", StandardCharsets.UTF_8);
        StoredMessageFile file = new StoredMessageFile(path);
        assertThrows(IOException.class, file::readMessages);
    }
}
